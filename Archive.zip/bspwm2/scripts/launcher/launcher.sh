#!/usr/bin/env bash

rofi -show drun -theme ~/.config/bspwm/scripts/launcher/style.rasi
