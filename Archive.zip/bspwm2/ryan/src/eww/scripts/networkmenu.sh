#!/usr/bin/env bash

networkmanager_dmenu &
